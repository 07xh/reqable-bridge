package com.reqable.bridge.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.reqable.bridge.MainActivity
import com.reqable.bridge.data.CaptureStore
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.GZIPInputStream

class ReportServerService : Service() {
    @Volatile private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private val workers = Executors.newFixedThreadPool(4)
    private val stopping = AtomicBoolean(false)
    private lateinit var store: CaptureStore

    override fun onCreate() {
        super.onCreate()
        store = CaptureStore(applicationContext)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
        acceptThread = Thread({ acceptLoop() }, "ReqableBridge-Accept").apply { start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopping.set(true)
        try { serverSocket?.close() } catch (_: Exception) { }
        workers.shutdownNow()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
        super.onDestroy()
    }

    private fun acceptLoop() {
        try {
            val socketServer = ServerSocket(PORT, 32, InetAddress.getByName("0.0.0.0"))
            serverSocket = socketServer
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, true).apply()
            while (!stopping.get()) {
                val client = socketServer.accept()
                workers.submit { handleClient(client) }
            }
        } catch (_: Exception) {
            if (!stopping.get()) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
            }
        }
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 20_000
                val input = BufferedInputStream(client.getInputStream())
                val output = BufferedOutputStream(client.getOutputStream())
                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(' ')
                if (parts.size < 2) {
                    writeResponse(output, 400, "Bad Request", "{\"ok\":false,\"error\":\"bad request line\"}")
                    return
                }
                val method = parts[0].uppercase()
                val path = parts[1].substringBefore('?')
                val headers = linkedMapOf<String, String>()
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    val separator = line.indexOf(':')
                    if (separator > 0) headers[line.substring(0, separator).trim().lowercase()] = line.substring(separator + 1).trim()
                }

                if (headers["expect"]?.equals("100-continue", ignoreCase = true) == true) {
                    output.write("HTTP/1.1 100 Continue\r\n\r\n".toByteArray(Charsets.US_ASCII))
                    output.flush()
                }

                if (method == "GET" && path == "/health") {
                    writeResponse(output, 200, "OK", "{\"ok\":true,\"service\":\"reqable-bridge-phone\"}")
                    return
                }

                val token = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_REPORT_TOKEN, "") ?: ""
                if (!client.inetAddress.isSiteLocalAddress) {
                    writeResponse(output, 403, "Forbidden", "{\"ok\":false,\"error\":\"private network only\"}")
                    return
                }
                if (method != "POST" || path != "/report/$token" || token.isBlank()) {
                    writeResponse(output, 404, "Not Found", "{\"ok\":false,\"error\":\"not found\"}")
                    return
                }

                val body = readRequestBody(input, headers)
                val decoded = when (headers["content-encoding"]?.lowercase()) {
                    null, "", "identity" -> body
                    "gzip" -> GZIPInputStream(ByteArrayInputStream(body)).use { readLimited(it, MAX_DECOMPRESSED_BYTES) }
                    else -> {
                        writeResponse(output, 415, "Unsupported Media Type", "{\"ok\":false,\"error\":\"unsupported content encoding\"}")
                        return
                    }
                }
                if (decoded.size > MAX_DECOMPRESSED_BYTES) {
                    writeResponse(output, 413, "Payload Too Large", "{\"ok\":false,\"error\":\"report too large\"}")
                    return
                }
                val json = decoded.toString(Charsets.UTF_8)
                val inserted = store.insertHar(json)
                val total = store.count()
                writeResponse(output, 200, "OK", JSONObject().put("ok", true).put("stored", inserted).put("total", total).toString())
            } catch (e: Exception) {
                try {
                    val output = BufferedOutputStream(client.getOutputStream())
                    writeResponse(output, 400, "Bad Request", JSONObject().put("ok", false).put("error", e.message ?: "invalid report").toString())
                } catch (_: Exception) { }
            }
        }
    }

    private fun readRequestBody(input: InputStream, headers: Map<String, String>): ByteArray {
        val transferEncoding = headers["transfer-encoding"]?.lowercase() ?: ""
        if (transferEncoding.contains("chunked")) return readChunked(input)
        val length = headers["content-length"]?.toLongOrNull() ?: 0L
        if (length < 0 || length > MAX_COMPRESSED_BYTES) throw IllegalArgumentException("invalid or oversized content length")
        val output = ByteArrayOutputStream(length.toInt())
        val buffer = ByteArray(8192)
        var remaining = length
        while (remaining > 0) {
            val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (read < 0) throw IllegalArgumentException("request body ended early")
            output.write(buffer, 0, read)
            remaining -= read
        }
        return output.toByteArray()
    }


    private fun readLimited(input: InputStream, maxBytes: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (output.size() + read > maxBytes) throw IllegalArgumentException("decompressed report too large")
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }

    private fun readChunked(input: InputStream): ByteArray {
        val output = ByteArrayOutputStream()
        while (true) {
            val sizeLine = readLine(input) ?: throw IllegalArgumentException("invalid chunked body")
            val sizeText = sizeLine.substringBefore(';').trim()
            val size = sizeText.toLongOrNull(16) ?: throw IllegalArgumentException("invalid chunk size")
            if (size == 0L) {
                while (true) {
                    val trailer = readLine(input) ?: break
                    if (trailer.isEmpty()) break
                }
                break
            }
            if (size < 0 || output.size().toLong() + size > MAX_COMPRESSED_BYTES) throw IllegalArgumentException("chunked body too large")
            var remaining = size
            val buffer = ByteArray(8192)
            while (remaining > 0) {
                val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read < 0) throw IllegalArgumentException("truncated chunk")
                output.write(buffer, 0, read)
                remaining -= read
            }
            input.read() // CR
            input.read() // LF
        }
        return output.toByteArray()
    }

    private fun readLine(input: InputStream): String? {
        val bytes = ByteArrayOutputStream()
        while (true) {
            val value = input.read()
            if (value < 0) return if (bytes.size() == 0) null else bytes.toString(Charsets.ISO_8859_1.name())
            if (value == 10) break
            if (value != 13) bytes.write(value)
            if (bytes.size() > 16 * 1024) throw IllegalArgumentException("HTTP header line too long")
        }
        return bytes.toString(Charsets.ISO_8859_1.name())
    }

    private fun writeResponse(output: BufferedOutputStream, status: Int, reason: String, json: String) {
        val body = json.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 $status $reason\r\n" +
            "Content-Type: application/json; charset=utf-8\r\n" +
            "Content-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.US_ASCII))
        output.write(body)
        output.flush()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reqable Bridge receiver", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Reqable Bridge 正在接收")
                .setContentText("电脑 Reqable 的 HTTP 会话将转发到本机")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Reqable Bridge 正在接收")
                .setContentText("电脑 Reqable 的 HTTP 会话将转发到本机")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        }
    }

    companion object {
        const val PORT = 8090
        const val PREFS = "reqable_bridge"
        const val KEY_REPORT_TOKEN = "report_token"
        const val KEY_RUNNING = "receiver_running"
        private const val CHANNEL_ID = "reqable_bridge_receiver"
        private const val NOTIFICATION_ID = 7101
        private const val MAX_COMPRESSED_BYTES = 24L * 1024L * 1024L
        private const val MAX_DECOMPRESSED_BYTES = 48 * 1024 * 1024
    }
}
