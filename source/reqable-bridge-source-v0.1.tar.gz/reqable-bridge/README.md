# Reqable Bridge — Windows + Android (source v0.1)

A local-only companion for sending completed HTTP sessions from Windows Reqable to an Android phone hotspot receiver, and controlling Reqable live capture from the phone.

## What this first source drop contains

- `windows-bridge/desktop.py`: small Windows desktop UI for configuring and starting the control bridge.
- `windows-bridge/bridge.py`: private-network HTTP control service for Reqable.
- `android/`: Kotlin/Jetpack Compose Android project with a foreground receiver, gzip HAR ingest, SQLite persistence, search, and request detail view.
- The Windows bridge can create/update the `Reqable Bridge` Report Server rule in Reqable and issue start/stop capture commands through Reqable's local API.

## Important behavior boundary

Reqable Report Server uploads a completed HTTP session as HAR JSON after that session completes. It is near-real-time per completed HTTP session, not a raw TCP/IP packet mirror. Reqable documents that each session is sent once and is not retried after a failed upload. See the official [Report Server documentation](https://reqable.com/en-US/docs/capture/report-server).

## Network topology

1. Turn on the phone hotspot.
2. Connect the Windows PC to that hotspot.
3. Start the Android receiver. It listens on `0.0.0.0:8090` and displays the hotspot-side IPv4 address and a per-install report token.
4. Start the Windows bridge with `windows-bridge/run.bat`. The desktop window shows its LAN IPv4 address and bridge pairing token; it listens on `0.0.0.0:8091`.
5. Enter the Windows bridge address/token in the Android app.
6. Tap **Configure Reqable automatic reporting**. The Windows bridge creates or updates the `Reqable Bridge` Report Server rule with wildcard `*` and Gzip compression.
7. Use the Android controls to start or pause Reqable live capture.

The phone and PC must be able to reach each other's hotspot-side addresses. Android hotspot client isolation or Windows Firewall can prevent this; the first hardware test must verify both directions.

## Reqable setup

The Windows bridge uses Reqable's local API routes. On current Reqable versions, the API service may be disabled by default and requires an access token. Enable the local API/MCP service in Reqable settings, create an access token, and enter the API port/token in `windows-bridge/config.json`. The Reqable MCP documentation describes the local API host/port behavior; the official MCP source exposes `capture_live_set_enabled` and Report Server management operations.

First run:

1. Copy `windows-bridge/config.example.json` to `windows-bridge/config.json`.
2. Set `reqable_api_token` to the token configured in Reqable.
3. Set `reqable_port` to the local API port shown by Reqable (default in this starter config: 9000; verify it on your installation).
4. Run `windows-bridge/run.bat`.

To build a standalone Windows executable on a Windows machine, run `windows-bridge/build_exe.bat`. Keep `config.json` beside the EXE.

## Android build

Open the `android/` directory in Android Studio with Android SDK 35 installed, sync Gradle, then build the `app` debug APK. Package versions are pinned in the Gradle files. This environment does not currently include Android SDK/Gradle, so no APK has been claimed as built or device-tested.

## Security and privacy

- Traffic stays on the local hotspot; no cloud relay is included.
- The Android report URL includes a high-entropy random token because Reqable Report Server does not provide a configurable Authorization header in its documented setup.
- The Windows bridge requires a separate Bearer token and only accepts private/loopback source IPs.
- The Reqable API token is separate from the bridge token.
- Captured requests can contain cookies, authorization headers, personal data, and session tokens. Keep the hotspot private and do not share HAR exports without reviewing them.

## Current limitations / next validation gates

- Source v0.1 only; not yet built into an APK or signed Windows EXE.
- The Android receiver uses a small HTTP/1.1 server and supports Content-Length, chunked transfer, and Gzip. Brotli and Zstandard are intentionally not advertised in the generated Reqable rule.
- Reqable Report Server delivery is one-shot; if the phone receiver is unavailable, Reqable does not retry. A later version can add a Windows-side durable queue or use a different Reqable integration if supported.
- The phone hotspot's inbound connectivity must be verified on the actual OnePlus device.
- The current request detail screen stores and displays raw HAR entry JSON; advanced binary/body decoding and HAR export are subsequent milestones.
- The Windows bridge currently has a basic Tkinter desktop window. A system-tray mode, automatic startup, and installer are later milestones.
